/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*"],
  theme: {
    screens: {
      xsm: '340px',
      sm: '640px',
      md: '768px',
      lg: '1024px',
      xl: '1280px',
      '2xl': '1536px',
    },
    extend: {
      spacing: {
        44: '11rem',
        0.5: '0.125rem',
      },
    },
    fontFamily: {
      sans: [
    
        'Roboto',]
      },
  },
  plugins: [],
}